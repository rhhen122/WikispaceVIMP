# License
## Info
- Wikispace is maintained by Roky Edward Iven Henderson (aka citrusdev) and is operated under VIMP (Visual Interface Maker Productive)
- Wikispace is useable by all.
- Wikispace uses Github® to host its files and Source code.
## Usage
- Wikispace is downloaded via git (https://git-scm.com/)
- Wikispace is based (To some extent) on Zonelets (https://zonelets.net/)
### Distrobution by the public
- Distrobution by the public is STONGLY vowed against by VIMP
- Distrobution on a Gross scale is against the CODE OF CONDUCT
